public class Demo {
    public static void main(String[] args){
        BinaryTree tree = new BinaryTree();

        //              5
        //        10         8
        //     13    4     3   17

        tree.root = new Node(5);
        tree.root.left = new Node(10);
        tree.root.right = new Node(8);
        tree.root.left.left = new Node(13);
        tree.root.left.right = new Node(4);
        tree.root.right.left = new Node(3);
        tree.root.right.right = new Node(17);

        System.out.println("Preorder");
        tree.preOrder(tree.root);
        System.out.println();

        System.out.println("Inorder");
        tree.inOrder(tree.root);
        System.out.println();

        System.out.println("Postorder");
        tree.postOrder(tree.root);
        System.out.println();

        tree.root1 = new Node(5);
        tree.root1.left = new Node(10);
        tree.root1.right = new Node(8);
        tree.root1.left.left = new Node(13);
        tree.root1.left.right = new Node(4);
        tree.root1.right.left = new Node(3);
        tree.root1.right.right = new Node(17);

        System.out.println("\nAre the two trees identical? \n" + tree.isSameTree(tree.root, tree.root1));

    }
}
