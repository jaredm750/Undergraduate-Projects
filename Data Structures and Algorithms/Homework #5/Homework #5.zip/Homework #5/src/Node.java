public class Node {
    public int val;
    public Node left;
    public Node right;

    Node (int val) {
        this.val = val;
        right = null;
        left = null;
    }
}