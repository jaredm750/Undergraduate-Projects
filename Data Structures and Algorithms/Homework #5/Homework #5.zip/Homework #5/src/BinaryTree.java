public class BinaryTree {
    Node root;
    Node root1;

    public BinaryTree(int data){
        root = new Node(data);
    }

    public BinaryTree() {
        root = null;
    }

    public Node getRoot(){
        return root;
    }

    public void add(Node parent, Node child, String orientation){
        if(orientation.equals("left")){
            parent.left = child;
        }
        else{
            parent.right = child;
        }
    }

    public void preOrder(Node node){
        if (node == null)
            return;

        System.out.print(node.val + "->");

        preOrder(node.left);

        preOrder(node.right);
    }

    public void inOrder(Node node){
        if (node == null)
            return;

        inOrder(node.left);

        System.out.print(node.val + "->");

        inOrder(node.right);
    }

    public void postOrder(Node node){
        if(node == null)
            return;

        postOrder(node.left);

        postOrder(node.right);

        System.out.print(node.val+ "->");
    }
    boolean isSameTree(Node p, Node q)
    {
        if (p == null && q == null) {
            return true;
        }
        if (p != null && q != null) {
            return (p.val == q.val && isSameTree(p.left, q.left) && isSameTree(p.right, q.right));
        }

        return false;
    }
}
